#!/usr/bin/env bash
# Starts the two open models as OpenAI-compatible vLLM servers on this machine's GPU.
#   :8000  txn-generator  Qwen2.5-7B-Instruct (tool calling)  -> generator agent
#   :8001  fraud-llm      fine-tuned Qwen2.5-1.5B             -> fraud-scoring agent
# Called by the repo-root app.sh. Weights are cached in the project dataset so only the
# first start downloads them.
set -uo pipefail

DS="${DOMINO_DATASETS_DIR:-/domino/datasets}/local/${DOMINO_PROJECT_NAME:-fraud-workshop}"
export HF_HOME="${HF_HOME:-$DS/hf_cache}"
GEN_MODEL="${GENERATOR_MODEL:-Qwen/Qwen2.5-7B-Instruct}"
FRAUD_MODEL_DIR="${FRAUD_MODEL_DIR:-$DS/models/fraud-llm}"
GEN_MEM="${GEN_GPU_MEM:-0.55}"      # share of GPU memory; sized for a 40-48 GB card
FRAUD_MEM="${FRAUD_GPU_MEM:-0.25}"
mkdir -p "$HF_HOME" /tmp/llm-logs

if ! command -v vllm >/dev/null || ! nvidia-smi >/dev/null 2>&1; then
  echo "serve_llms: no GPU or no vllm in this environment; skipping LLM servers."
  exit 0
fi

pkill -f "vllm serve" 2>/dev/null || true

vllm serve "$GEN_MODEL" --served-model-name txn-generator --port 8000 \
  --gpu-memory-utilization "$GEN_MEM" --max-model-len 8192 \
  --enable-auto-tool-choice --tool-call-parser hermes \
  > /tmp/llm-logs/generator.log 2>&1 &

if [ -d "$FRAUD_MODEL_DIR" ]; then
  vllm serve "$FRAUD_MODEL_DIR" --served-model-name fraud-llm --port 8001 \
    --gpu-memory-utilization "$FRAUD_MEM" --max-model-len 1024 \
    > /tmp/llm-logs/fraud.log 2>&1 &
else
  echo "serve_llms: $FRAUD_MODEL_DIR not found. Run finetune_fraud_llm.py as a Job first."
fi
echo "serve_llms: servers starting (logs in /tmp/llm-logs). First start downloads weights."
